# engineering

Role: Reference-project engineering

Prepare narrowly scoped deduplication and deterministic ordering fixes without rewriting the project.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
