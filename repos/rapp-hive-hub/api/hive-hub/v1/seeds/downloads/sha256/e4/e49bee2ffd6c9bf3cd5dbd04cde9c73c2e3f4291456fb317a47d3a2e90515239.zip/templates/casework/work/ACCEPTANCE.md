# Case acceptance

- Each of the five units receives an intake and an explicit active, parked, or rejected recommendation.
- The proposed selection uses at most 32 discretionary hours, USD 500, and three business units, with no more than one experiment per unit.
- All confidence values remain labeled subjective SYNTHETIC planning inputs, not measured demand probabilities.
- The offline allocation tool and CSV preflight checks can be reproduced without installs, network access, or publication.
- A human owner can review the decision, reserves, unallocated capacity, assumptions, and approval gates.

No reference artifact counts as completed work without review.
