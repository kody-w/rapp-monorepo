# The Open-Source Infrastructure Foundation

Coordinate maintainers, triage, engineering, security, documentation, release, and community around a deliberately imperfect offline event reducer, preserving honest failures and evidence-based release gates.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Line Ledger: repair duplicate counting and out-of-order state reduction**

Line Ledger is an original Python standard-library reference, not copied infrastructure or a real private project. Its SYNTHETIC JSONL fixtures model harmless open/close events for fictional work items. The implementation deliberately counts repeated identical event IDs twice and follows arrival order instead of event time. One clean contract case passes; two defect cases fail. The organization must reproduce, repair, review, and only then consider release.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **maintainers**: Own the reference contract, narrow scope, review decisions, and release authority boundaries.
- **triage**: Reproduce the two deliberate logic defects and turn each into precise repair work.
- **engineering**: Prepare narrowly scoped deduplication and deterministic ordering fixes without rewriting the project.
- **security**: Review bounded inert data handling and prevent file, network, command, or identity capabilities from being added.
- **docs**: Keep quickstart, behavior, repair guidance, and release notes aligned with observed code.
- **release**: Enforce strict contract checks and plan any later separately approved publication.
- **community**: Prepare respectful synthetic issue intake and honest announcement drafts without outreach.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
