# The Applied Invention Lab

Coordinate research, experiments, prototyping, replication, and commercialization around reproducible synthetic library-kit tote packing, with a runnable baseline and explicit limits on physical and business claims.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Library Kit Tote Study: does a two-capacity heuristic actually reduce modeled bins?**

A fictional library kit service wants a more explainable way to group harmless paper, cloth, foam, and counting materials into reusable totes. All items, capacities, shapes, and operating assumptions are SYNTHETIC. Eleven item-type rows expand into 29 instances across four scenarios. The offline reference compares input-order, dominant-load, and volume-first greedy packing, verifies every assignment, and optionally proves small scalar-model optima. It does not certify three-dimensional fit, lifting safety, physical performance, or commercial demand.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **research**: Define the practical question, assumptions, decision criteria, and honest limits of the scalar model.
- **experiments**: Run the baseline and seeded comparisons without cherry-picking favorable scenarios.
- **prototyping**: Turn computed assignments into reviewable packing instructions and a later physical-fit study.
- **replication**: Audit the original dataset and reproduce checks, hashes, assignments, and limits.
- **commercialization**: Prepare a bounded opportunity hypothesis without fabricated demand, patents, savings, or customers.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
