# architecture

Role: Solution architecture

Define a replaceable pure calculation boundary and human-owned exception routing.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
