# Quality Assurance

Role: qa-lead

Check solvability, input handling, no-network behavior, accessibility limits, and regressions.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
