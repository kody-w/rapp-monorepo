# portfolio-research

Role: Shared research

Separate assumptions, public desk research, and later consented field evidence.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
