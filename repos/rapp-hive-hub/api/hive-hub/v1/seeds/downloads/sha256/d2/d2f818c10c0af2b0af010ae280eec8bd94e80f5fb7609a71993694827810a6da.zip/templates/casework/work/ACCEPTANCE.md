# Case acceptance

- Fifteen synthetic cash rows reconcile USD 52000 opening cash plus USD 48500 receipts less USD 68100 payments to USD 32400 closing cash.
- USD 5500 incremental prior-period payables are reserved separately; runway to the USD 12000 floor is about 49.7 days under the repeated-September scenario.
- The alphabetical dispatch defect is reproducible and a candidate policy prioritizes eligible urgent tickets without dispatching a blocked ticket.
- The support simulation selects six tickets totaling exactly 420 estimated minutes and retains all other tickets as blocked or deferred.
- Any proposed USD 1700 monthly containment difference remains an approval-dependent scenario, not achieved savings, profit, sales, or executed financial activity.

No reference artifact counts as completed work without review.
