# Case acceptance

- The untouched reference characterizes one passing and two failing strict contract cases; failures are not hidden as completed fixes.
- Repair proposals address identical-ID deduplication and deterministic ordering by at_minute then event_id.
- Bounded input validation, conflict rejection, no-mutation behavior, and offline operation are preserved.
- A release candidate requires the strict contract checker to pass every case plus reviewed regression tests.
- Source ownership, remaining limitations, and external publication approvals are explicit.

No reference artifact counts as completed work without review.
